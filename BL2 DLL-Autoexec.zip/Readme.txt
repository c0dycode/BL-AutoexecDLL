This is a new testversion of the autoexec.

# A few notes:

- Should this cause a crash for you, it should create a "autoexec.dmp"-file in the Plugins folder.
  Make sure to send that file to me.

- Due to it being a testversion, it's filesize increased a lot, compared to the older ones. Once the issues are fixed, that'll change again.

# How to install:
Drag and drop the "ddraw.dll" and the "Plugins"-folder into your Win32-folder, where your Borderlands executable is located at.
Revert any previously installed versions of the autoexec.